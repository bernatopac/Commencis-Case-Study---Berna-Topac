from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://techcrunch.com/")


element = driver.find_element(By.XPATH,"//*[@id='tc-main-content']/div[3]/div/div/div/article[4]/header/h2/a")
driver.execute_script("arguments[0].scrollIntoView();", element)
author_name = driver.find_element(By.XPATH, "//*[@id='tc-main-content']/div[3]/div/div/div/article[6]/header/div[2]/div/span/span/a")
text = author_name.text
print(text)
if author_name:
    print("Author name is full")
else:
    print("Author name could not find")
WebDriverWait(driver,10)

