from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://techcrunch.com/")


element = driver.find_element(By.XPATH,"//*[@id='tc-main-content']/div[3]/div/div/div/article[1]/header/h2/a")
driver.execute_script("arguments[0].scrollIntoView();", element)
element.click()
browser_title = driver.title
article_title = driver.find_element(By.CSS_SELECTOR,".article__title")
text = article_title.text
print(text)
print(browser_title)
WebDriverWait(driver,10)

if browser_title == article_title:
    print("They're same")
else:
    print("They're not same")
